# Mikroişlemciler Sunu 2025

*Bu doküman PDF'den otomatik olarak dönüştürülmüştür.*

---

## Sayfa 1

Mikroişlemciler 
2025 -2026 Güz Dönemi 
Bilgisayar Mühendisliği 
Lisans 
Ders I : Ders İçerikleri 

---

## Sayfa 2

Mikroişlemciler Ders İçeriği 
 


---

## Sayfa 3

Öğrenme Çıktıları 
- Mikroişlemci kavramlarını bilme 
- Hafıza Temelleri, Adresleme ve Ortak veri yolu 
kavramlarını bilme 
- C Derleyicileri ve Proteus, Wokwi gibi simulasyon 
programlarını kullanabilme 
- Mikrodenetleyici programlayabilme 

---

## Sayfa 4

Ölçme ve Değerlendirme Ölçütleri 
   
Değerlendirme Ölçütleri 
Varsa (X) 
olarak 
işaretleyini
z 
Yüzde 
(%) 
Ara sınavlar (Klasik Sınav) X 20 
Kısa sınavlar -  - 
Ödevler  X  10 
Laboratuar  -  - 
Uygulama Ödevi (Dönem Sonu) X 40  
Dönem sonu sınavı (Klasik Sınav) X 30 
Devamsızlık 
Her hafta yoklama alınır. 

---

## Sayfa 5

Örnek Uygulamalar 
  
ESP32 


---

## Sayfa 6

Örnek Uygulamalar 
- ESP32 Web  


---

## Sayfa 7

Örnek Uygulamalar  
ESP32 ile Robot Kol 
 
 
 


---

## Sayfa 8

Örnek Uygulamalar 


---

## Sayfa 9

Örnek Uygulamalar 
 
 
 
 
 
 
 
 
FACE DETECTION 


---

## Sayfa 10

Örnek Uygulamalar 


---

## Sayfa 11

Örnek Uygulamalar 
ByLink Üzerinden https://www.blynk.io/ 
 
 
 
 
 
 
 
 
 
M2M Uygulaması Endüstri 4.0 


---

## Sayfa 12

Örnek Uygulamalar 
 
 
 
 
 
 
 
NTP Server İnternet Saat ve İnternet 
Termometre 


---

## Sayfa 13

Örnek Uygulamalar 
 
 
 
 
 
 
 
ESP32 Hexapod 


---

## Sayfa 14

Örnek Uygulamalar 
 
 
 
 
 
 
 
 
ESP32 Su seviyesi ölçümü 


---

## Sayfa 15

Örnek Uygulamalar 
 
 
 
 
 
 
 
 
AWS IoT Lamp || Control Relay/LED 


---

## Sayfa 16

Örnek Uygulamalar 
 
 
 
 
 
 
 
 
ESP32 ile Whatsapp 


---

## Sayfa 17

İletişim Bilgilerim 
 
 
Kenan ZENGİN 
Gaziosmanpaşa Üniversitesi 
Mühendislik ve Mimarlık Fakültesi 
Bilgisayar Mühendisliği Bölümü 
Taşlıçiftlik Yerleşkesi 
Kat:3  PK:60240  
Taşlıçiftlik/Merkez/TOKAT /TÜRKİYE 
E-posta : kenan.zengin@gop.edu.tr 
Tel: +90 356 252 1616 (2930) 
Web : ue.gop.edu.tr 

---

## Sayfa 18

Mikroişlemciler 
2025-2026 Güz Dönemi 
Bilgisayar Mühendisliği 
Lisans 
Ders II : Genel Kavramlar 

---

## Sayfa 19

Mikroişlemciler 
 


---

## Sayfa 20

Mikroişlemciler 
 


---

## Sayfa 21

Mikroişlemciler 


---

## Sayfa 22

Mikroişlemciler 


---

## Sayfa 23

Mikroişlemci ve Mikrobilgisayar 
 
Mikrobilgisayar : Bir tüm devre (chip)üzerinde üretilen bilgisayardır. 
Mikrokontroller yada Mikro denetliyici olarak da adlandırılır. 


---

## Sayfa 24

Mikroişlemci ve Mikrobilgisayar 
 
Mikrobilgisayar : Bir tüm devre (chip)üzerinde üretilen bilgisayardır. 
Mikrokontroller yada Mikro denetliyici olarak da adlandırılır. 


---

## Sayfa 25

Tek Çekirdekli ve Çok Çekirdekli 
Mikroişlemciler 


---

## Sayfa 26

Mikroişlemci ve Mikrobilgisayar 
 Arasındaki Farklar 


---

## Sayfa 27

Mikroişlemci ve Mikrobilgisayar 
 
CPU : Hafızaya yüklü programın çalışmasını sağlayan birimdir. 
ALU : CPU içerisindeki matematiksel işlemlerin yapıldığı birimdir. 
Kontrol Birimi : Tüm işlemlerin sırasını belirler ve gerekli denetim 
işaretlerini üretir. Aynı zamanda bellekten okunan kodların çözümü de 
bu birimde yapılır. 


---

## Sayfa 28

Sayı Sistemleri 
 
Desimal (Onluk) Sistem 


---

## Sayfa 29



---

## Sayfa 30



---

## Sayfa 31



---

## Sayfa 32



---

## Sayfa 33



---

## Sayfa 34



---

## Sayfa 35

Yarıiletken maddeler; elektrik akımına karşı, ne iyi bir iletken nede iyi bir 
yalıtkan özelliği gösterirler. Elektronik endüstrisinin temelini oluşturan 
yarıiletken maddelere örnek olarak; silisyum (si), germanyum (ge) ve 
karbon (ca) elementlerini verebiliriz. Bu elementler son yörüngelerinde 
4 adet valans elektron bulundururlar. 


---

## Sayfa 36



---

## Sayfa 37

Transistörlerin Gelişimi 
• Elektromanyetik aktarıcıların 
yerlerine vakum tüpleri 
geçmiştir. 
• Bilgisayarların boyutları 
küçülmüştür. 
• Vakum tüpleri yüksek 
derecede ısı üretmekte ve 
çok çabuk bozulmaktadır. 
• 1948 yılında AT&T Bell 
laboratuarlarında, John 
Bardeen, Walter Brittain ve 
William Shockley tarafından 
ilk transistör üretilmiştir.  


---

## Sayfa 38



---

## Sayfa 39



---

## Sayfa 40



---

## Sayfa 41



---

## Sayfa 42



---

## Sayfa 43



---

## Sayfa 44



---

## Sayfa 45



---

## Sayfa 46



---

## Sayfa 47



---

## Sayfa 48



---

## Sayfa 49



---

## Sayfa 50



---

## Sayfa 51



---

## Sayfa 52



---

## Sayfa 53



---

## Sayfa 54



---

## Sayfa 55



---

## Sayfa 56

Mikroişlemcili sistemlerde birimler arası veri transferinin 
gerçekleştirebilmesi için tüm birimler veriyoluna bağlanmak zorundadır. 
Bu durum ortak yol oluşturma problemini oluşturur.  
 
Bu problem ise 3 durumlu buffer’lar ile çözülmektedir. 
      

---

## Sayfa 57



---

## Sayfa 58



---

## Sayfa 59



---

## Sayfa 60



---

## Sayfa 61



---

## Sayfa 62



---

## Sayfa 63



---

## Sayfa 64



---

## Sayfa 65



---

## Sayfa 66



---

## Sayfa 67



---

## Sayfa 68



---

## Sayfa 69



---

## Sayfa 70



---

## Sayfa 71



---

## Sayfa 72



---

## Sayfa 73



---

## Sayfa 74



---

## Sayfa 75



---

## Sayfa 76



---

## Sayfa 77



---

## Sayfa 78



---

## Sayfa 79



---

## Sayfa 80



---

## Sayfa 81



---

## Sayfa 82



---

## Sayfa 83



---

## Sayfa 84



---

## Sayfa 85



---

## Sayfa 86

Şekil : 16 KB lık bellek modülleri ile oluşturulmuş tasarım 

---

## Sayfa 87

Soru : 8 bitlik veriyolu ve 16 bitlik adres yolu olan bir mikroişlemcili 
sistemin adresleyebileceği hafıza miktarı nedir? 
 
 
Soru : 8 bit 18K ‘lık bir hafıza birimini adresleyebilmek için kaç adres 
bitine ihtiyaç vardır. 
 
 
Soru : 800MHz lik saat girişine sahip ve 16 bit veriyolu olan 64KB lık 
bir RAM modülden ortak veriyolu üzerinden saniyede kaç bit veri 
okunabilir? 

---

## Sayfa 88

Mikroişlemci Mimarileri 

---

## Sayfa 89

Mikrodenetleyici mimarileri hafıza 
organizasyonu açısından ya da komut işleme 
tekniği açısından sınıflandırılabilir. 
 
Hafıza organizasyonu açısından 
mikrodenetleyiciler Von Neuman ve Harvard 
olmak üzere iki mimari üzerine tasarlanır. 
Geçmişte Von Neuman mimarisi tercih edilse 
de 1970’li yılların sonlarında Harvard mimarisi 
mikrodenetleyici tasarımında standart hale 
gelmiştir. 

---

## Sayfa 90

Von Neuman Mimarisi  
Von Neuman mimarisinde tümleşik tek bellek 
bulunur. Yani veri ve program alanı aynı hafıza 
haritası üzerinde bulunur. Bu mimari 80X86, 
68HC11, v.b. işlemcilerde kullanılmıştır. PC olarak 
bilinen kişisel bilgisayarlar arasında standarttır. 


---

## Sayfa 91

Von Neuman Mimarisi  
İşlem biriminin bellek biriminden ayrıştırılması bu 
mimarinin en önemli özelliğidir. Komut ve veri için 
aynı belleğin kullanıldığı ‘Von Neuman Mimarisinde’, 
komut ve veriler aynı yol kullanılarak iletilirler. Bu 
durum, komut ve verinin iletilmesinin gerektiği 
durumlarda veri ile ilgili iletişim sistemlerinin, komut 
ile ilgili iletişim işlemlerini beklemesini gerektirir.  

---

## Sayfa 92

John von Neumann 
• John von Neumann, 
bilgisayar bilimlerinin 
öncülerindendir.  
• Bilgisayar 
organizasyon yapısını 
1950lerde öngörmüş 
ve bunu biçimsel hale 
getirmiştir.  
• Bu mimari bir dönüm 
noktası olmuştur. 


---

## Sayfa 93

Harvard Mimarisi 
Bu mimaride veri ve komutları iletmek amacıyla 
kullanılan yollar birbirinden bağımsızdır. İletim için 
kullanılan yolların farklı olması, aynı anda veri ve 
komutun iletilmesini mümkün hale getirir. Diğer bir 
ifadeyle, komut kod bellekten okunurken, komutun 
gerçekleştirilmesi sırasında ihtiyaç duyulan veri, veri 
belleğinden okunabilir. 


---

## Sayfa 94



---

## Sayfa 95



---

## Sayfa 96



---

## Sayfa 97



---

## Sayfa 98



---

## Sayfa 99



---

## Sayfa 100



---

