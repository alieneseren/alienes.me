#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("📝 Modül 7 ve 8 oluşturuluyor...")
print("✅ Bu işlem tamamlanacak, lütfen bekleyin...")

# Modül 7 ve 8'i tek dosyada oluşturma
import os
os.system('echo "Modül 7-8 oluşturma başladı..."')
